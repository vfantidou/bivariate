//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bivariate.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BIVARITYPE                  129
#define IDD_ALGOPTIONS                  130
#define IDC_DETITER                     1000
#define IDC_RNDITER                     1001
#define IDD_PSET3D                      1004
#define IDC_PLIST                       1010
#define IDC_VIEW3D                      1015
#define IDC_EDIT_Z                      1017
#define IDC_OPTIONS                     1018
#define IDC_SET                         1019
#define IDC_ZHEIGHT                     1021
#define IDC_GLOPTIONS                   1022
#define ID_ACTIONS_BIVARIATE            32771
#define ID_ACTIONS_DET                  32772
#define ID_ACTIONS_RND                  32773
#define ID_VIEW_AXIS                    32774
#define ID_VIEW_DATAMESH                32775
#define ID_VIEW_LOWERGRID               32776
#define ID_VIEW_UPERGRID                32777
#define ID_VIEW_DATAPOINTS              32778
#define ID_COLOR_INVERT                 32779
#define ID_ATTRACTOR_POINTS             32780
#define ID_ATTRACTOR_MESH               32781
#define ID_ATTRACTOR_SOLID              32782
#define ID_MISC_STATISTICS              32783
#define ID_ACTIONS_OPTIONS              32784
#define ID_VIEW_PERSPECTIVE             32785
#define ID_VIEW_ORTHOGRAPHIC            32786
#define ID_MISC_ANIMATE                 32787
#define ID_FRACTAL_DATASET              32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
